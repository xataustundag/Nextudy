NEXTUDY WEB SİTESİ - İNDİRİLEBİLİR KOPYA

Bu paket Home, About, Privacy, Login, Register, How It Works, Rules ve Contact Us sayfalarını, stilleri, JavaScript dosyasını ve mavi tilki maskotunu içerir.

Bilgisayarda açmak için:
1. ZIP dosyasını çıkarın.
2. Terminalde Nextudy-website klasörüne girin.
3. Python 3 kuruluysa şu komutu çalıştırın: python3 -m http.server 8000
   Windows üzerinde gerekirse: py -m http.server 8000
4. Tarayıcıda http://localhost:8000 adresini açın.
5. Sunucuyu durdurmak için terminalde Ctrl+C tuşlarına basın.

Dosyaları bir statik web barındırma hizmetine yükleyecekseniz Nextudy-website klasörünün İÇİNDEKİ dosyaları sitenin kök dizinine koyun.

NOT: Bu sürüm bir tasarım önizlemesidir. Login/Register gerçek hesap açmaz; Contact Us mesaj göndermez. Gizlilik metni de taslaktır.

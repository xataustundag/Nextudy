const menuButton = document.querySelector('.menu-button');
const nav = document.querySelector('.primary-nav');
if (menuButton && nav) menuButton.addEventListener('click', () => {
  const open = menuButton.getAttribute('aria-expanded') !== 'true';
  menuButton.setAttribute('aria-expanded', String(open));
  nav.classList.toggle('is-open', open);
});
const contactForm = document.querySelector('.contact-form');
if (contactForm) contactForm.addEventListener('submit', event => {
  event.preventDefault();
  const status = contactForm.querySelector('.form-status');
  status.textContent = 'This is a design preview. Your message has not been sent.';
  status.hidden = false;
  contactForm.reset();
});
